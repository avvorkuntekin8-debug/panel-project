from flask import Flask, render_template, redirect, url_for, request
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from models import db, User, Link, Product
from datetime import datetime, timedelta
import uuid
import re
import os
from werkzeug.utils import secure_filename
from sqlalchemy import text





app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+pymysql://root:mede3342@localhost/eski_db"



db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = "static/uploads"

import os
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/mysql-test")
def mysql_test():
    result = db.session.execute(text("SHOW TABLES")).fetchall()
    return {"tables": [str(r[0]) for r in result]}

from sqlalchemy import text

@app.route("/search")
def universal_search():

    search_type = request.args.get("type")
    keyword = request.args.get("q")

    if not keyword or not search_type:
        return {"results": []}

    column_map = {
        "tc": "TC",
        "gsm": "GSM",
        "adsoyad": "AD",
        "babaadi": "BABAADI",
        "anneadi": "ANNEADI",
        "adres": "ADRESIL"
    }

    if search_type not in column_map:
        return {"results": []}

    column = column_map[search_type]

    query = text(f"""
        SELECT ID, AD, SOYAD, TC, GSM
        FROM 109mtcpro
        WHERE {column} LIKE :kw
        LIMIT 20
    """)

    results = db.session.execute(
        query,
        {"kw": f"%{keyword}%"}
    ).fetchall()

    return {
        "results": [
            {
                "ID": r[0],
                "AD": r[1],
                "SOYAD": r[2],
                "TC": r[3],
                "GSM": r[4]
            }
            for r in results
        ]
    }



# ---------------- SLUG ----------------
def slugify(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9]+', '-', text)
    return text.strip('-')


# ---------------- LOGIN ----------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        user = User.query.filter_by(username=username, password=password).first()

        if user:
            login_user(user)
            if user.role == "admin":
                return redirect(url_for("admin_dashboard"))
            else:
                return redirect(url_for("user_dashboard"))

    return render_template("login.html")
    


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


# ---------------- DASHBOARDS ----------------
@app.route("/admin")
@login_required
def admin_dashboard():
    if current_user.role != "admin":
        return "Yetkisiz erişim!", 403
    return render_template("admin.html", user=current_user)


@app.route("/user")
@login_required
def user_dashboard():
    if current_user.role != "user":
        return "Yetkisiz erişim!", 403

    user_links = Link.query.filter_by(user_id=current_user.id).all()
    products = Product.query.filter_by(user_id=current_user.id).all()

    total_links = len(user_links)
    active_links = sum(1 for l in user_links if l.expires_at > datetime.utcnow())
    expired_links = total_links - active_links

    return render_template(
        "user.html",
        user=current_user,
        links=user_links,
        products=products,
        total_links=total_links,
        active_links=active_links,
        expired_links=expired_links
    )


# ---------------- PRODUCT EKLE ----------------
@app.route("/add-product", methods=["POST"])
@login_required
def add_product():

    title = request.form.get("title")
    price = request.form.get("price")
    description = request.form.get("description")
    seller_name = request.form.get("seller_name")
    seller_phone = request.form.get("seller_phone")
    city = request.form.get("city")
    category = request.form.get("category")
    iban = request.form.get("iban")
    status = request.form.get("status")

    filename = None

    if "image" in request.files:
        file = request.files["image"]
        if file and file.filename != "":
            filename = file.filename
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

    new_product = Product(
        title=title,
        price=price,
        description=description,
        seller_name=seller_name,
        seller_phone=seller_phone,
        city=city,
        category=category,
        iban=iban,
        status=status,
        image=filename,
        user_id=current_user.id
    )

    db.session.add(new_product)
    db.session.commit()

    return {
        "success": True
    }


# ---------------- PRODUCT LINK OLUŞTUR ----------------
@app.route("/generate-product/<int:product_id>", methods=["POST"])
@login_required
def generate_product_link(product_id):

    product = Product.query.get(product_id)

    if not product:
        return {"error": "Ürün bulunamadı"}, 404

    duration = int(request.form.get("duration"))
    site = request.form.get("site")

    expires_at = datetime.utcnow() + timedelta(hours=duration)

    token = uuid.uuid4().hex[:12]

    new_link = Link(
        token=token,
        product_id=product.id,
        user_id=current_user.id,
        expires_at=expires_at,
        site_type=site
    )

    db.session.add(new_link)
    db.session.commit()

    base_url = request.host_url.rstrip("/")
    slug = slugify(product.title)

    final_url = f"{base_url}/{site}/ilan/{slug}-{token}"

    return {"url": final_url}






@app.route("/<site>/ilan/<slug_token>")
def dynamic_product_view(site, slug_token):

    short_token = slug_token.split("-")[-1]

    link = Link.query.filter(
        Link.token.like(f"{short_token}%"),
        Link.site_type == site
    ).first()

    if not link:
        return "Link bulunamadı"

    if datetime.utcnow() > link.expires_at:
        return "Link süresi dolmuş"

    product = Product.query.get(link.product_id)

    return render_template(
        "market_theme.html",
        product=product,
        site=site
    )
        



# ---------------- DB INIT ----------------
if __name__ == "__main__":
    with app.app_context():
        db.create_all()

        if not User.query.filter_by(username="admin").first():
            admin = User(username="admin", password="1234", role="admin")
            db.session.add(admin)

        if not User.query.filter_by(username="user1").first():
            user1 = User(username="user1", password="1234", role="user")
            db.session.add(user1)

        db.session.commit()

    app.run(debug=True)
